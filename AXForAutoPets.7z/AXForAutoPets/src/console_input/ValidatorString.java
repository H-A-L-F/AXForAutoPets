package console_input;

public interface ValidatorString {
    public abstract boolean validateStr(String x);
}
