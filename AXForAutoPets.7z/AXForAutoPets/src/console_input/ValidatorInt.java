package console_input;

public interface ValidatorInt {
    public abstract boolean validateInt(int x);
}
