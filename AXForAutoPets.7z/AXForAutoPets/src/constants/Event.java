package constants;

public enum Event {
    ANT1,
    ANT2,
    ANT3;
}
