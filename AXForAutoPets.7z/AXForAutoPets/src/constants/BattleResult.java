package constants;

public enum BattleResult {
    WIN,
    LOSE,
    DRAW;
}