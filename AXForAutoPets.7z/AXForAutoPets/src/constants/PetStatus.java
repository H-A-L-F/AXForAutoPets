package constants;

public enum PetStatus {
    NORMAL,
    FAINT
}
