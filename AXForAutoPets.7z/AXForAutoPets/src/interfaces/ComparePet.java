package interfaces;

import models.Pet;

public interface ComparePet {
    Pet comparePet(Pet pet1, Pet pet2);
}
