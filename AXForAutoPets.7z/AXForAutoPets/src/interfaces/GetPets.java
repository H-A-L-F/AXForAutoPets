package interfaces;

import models.Pet;

import java.util.ArrayList;

public interface GetPets {
    ArrayList<Pet> getPets();
}
