package interfaces;

import models.Pet;

public interface OnFriendAttack {
    void onFriendAttack(Pet pet);
}
