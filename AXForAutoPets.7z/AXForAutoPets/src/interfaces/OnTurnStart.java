package interfaces;

public interface OnTurnStart {
    public abstract void onTurnStart();
}
