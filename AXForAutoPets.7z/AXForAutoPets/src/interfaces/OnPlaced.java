package interfaces;

public interface OnPlaced {
    public abstract void onPlaced();
}
