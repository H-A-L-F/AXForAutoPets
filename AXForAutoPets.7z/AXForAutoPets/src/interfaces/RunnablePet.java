package interfaces;

import models.Pet;

public interface RunnablePet {
    void runPet(Pet pet);
}
