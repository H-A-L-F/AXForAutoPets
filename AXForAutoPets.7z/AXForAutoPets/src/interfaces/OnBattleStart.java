package interfaces;

public interface OnBattleStart {
    public abstract void onBattleStart();
}
