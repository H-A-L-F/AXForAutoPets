package interfaces;

import constants.Event;

public interface EventListener {
    public abstract void update(Event event);
}
