package interfaces;

import models.Pet;

public interface OnSummon {
    public abstract void onSummon(Pet pet);
}
