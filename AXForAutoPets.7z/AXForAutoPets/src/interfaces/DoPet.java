package interfaces;

import models.Pet;

public interface DoPet {
    public abstract void doPet(Pet pet);
}
