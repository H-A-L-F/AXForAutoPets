package interfaces;

import models.Pet;

public interface OnFriendFaint {
    void onFriendFaint(Pet pet);
}
