package interfaces;

import models.Pet;

public interface GetPet {
    Pet getPet();
}
