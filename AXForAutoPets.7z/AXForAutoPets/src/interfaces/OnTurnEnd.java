package interfaces;

public interface OnTurnEnd {
    void onTurnEnd();
}
