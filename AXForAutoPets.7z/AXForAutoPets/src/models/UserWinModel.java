package models;

public class UserWinModel {
    public int id;
    public String name;
    public int win;

    public UserWinModel(int id, String name, int win) {
        this.id = id;
        this.name = name;
        this.win = win;
    }
}
